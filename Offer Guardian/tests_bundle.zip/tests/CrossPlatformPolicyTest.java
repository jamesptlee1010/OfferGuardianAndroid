package com.personal.offerguardian;
public final class CrossPlatformPolicyTest {
    static int n=0;
    static void ok(boolean b,String m){if(!b)throw new AssertionError(m);n++;}
    public static void main(String[] args){
        String dd=OfferSurfacePolicy.DOORDASH,ub=OfferSurfacePolicy.UBER;
        OfferSurfacePolicy.Host U=OfferSurfacePolicy.Host.UBER,D=OfferSurfacePolicy.Host.DOORDASH,O=OfferSurfacePolicy.Host.OTHER;
        ok(CrossPlatformPolicy.isDashOfferNotification(dd,"Dasher","New Delivery!",null),"actual notification");
        ok(CrossPlatformPolicy.isDashOfferNotification(dd,"  NEW  DELIVERY!! "),"normalised notification");
        ok(CrossPlatformPolicy.isDashOfferNotification(dd,"New delivery offer"),"variant");
        ok(!CrossPlatformPolicy.isDashOfferNotification(ub,"New Delivery!"),"wrong package");
        ok(!CrossPlatformPolicy.isDashOfferNotification(dd,"Your new delivery is complete"),"completion not trigger");
        ok(!CrossPlatformPolicy.isDashOfferNotification(dd,"You have a new message"),"message not trigger");
        ok(!CrossPlatformPolicy.isDashOfferNotification(dd,"New Delivery! already expired"),"expired text not trigger");
        ok(!CrossPlatformPolicy.isDashOfferNotification(dd,(String[])null),"missing text");
        ok(CrossPlatformPolicy.freshNotice(1000,16999),"fresh notification");
        ok(!CrossPlatformPolicy.freshNotice(1000,17001),"stale notification");
        ok(!CrossPlatformPolicy.freshNotice(1000,999),"rebooted clock");
        ok(!CrossPlatformPolicy.freshNotice(0,0),"no notification");
        ok(CrossPlatformPolicy.scan(D,true,false,false,false,false),"Uber over DD even DD off");
        ok(CrossPlatformPolicy.scan(O,true,false,true,false,false),"overlay over other app");
        ok(CrossPlatformPolicy.scan(O,true,false,false,true,false),"Uber event initiates detection");
        ok(CrossPlatformPolicy.scan(O,false,true,false,false,true),"notification initiates capture");
        ok(!CrossPlatformPolicy.scan(O,true,true,false,false,false),"no idle arbitrary scan");
        ok(!CrossPlatformPolicy.scan(O,false,true,true,true,false),"Uber disabled");
        ok(CrossPlatformPolicy.allowUberDecline(D,true,true,.97),"Uber X owned over DD");
        ok(CrossPlatformPolicy.allowUberDecline(O,true,true,.97),"Uber X owned over other app");
        ok(!CrossPlatformPolicy.allowUberDecline(D,false,true,.99),"unowned or obscured X");
        ok(!CrossPlatformPolicy.allowUberDecline(D,true,false,.99),"missing identity on overlay");
        ok(!CrossPlatformPolicy.allowUberDecline(D,true,true,.89),"weak template");
        ok(CrossPlatformPolicy.allowUberDecline(U,true,true,.97),"native Uber");
        ok(CrossPlatformPolicy.idleUber("You're online Finding trips"),"idle Uber");
        ok(!CrossPlatformPolicy.idleUber("You're online Finding trips Navigate to pickup"),"delivery protection");
        ok(!CrossPlatformPolicy.idleUber("You're online"),"insufficient idle evidence");
        ok(!CrossPlatformPolicy.idleUber("You're online Finding trips Accept"),"offer present");
        System.out.println("Cross-platform policy: "+n+" tests PASS");
    }
}
