package com.personal.offerguardian;
import java.util.*;
public class DoorDashOfferStandaloneTest {
    private static OfferScreenEvaluator.Line l(String t,int x,int y,int r,int b){return new OfferScreenEvaluator.Line(t,x,y,r,b);}
    private static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
    private static List<OfferScreenEvaluator.Line> offer(String payout,String metrics,String merchant,String time,boolean address,boolean promo){
        List<OfferScreenEvaluator.Line> a=new ArrayList<>();
        a.add(l("Decline",515,92,625,124));a.add(l(payout,30,890,245,953));a.add(l(metrics,30,980,470,1026));
        a.add(l(merchant,90,1102,400,1145));if(address)a.add(l("111 Kirby Road, Aspley, 4034 QLD",90,1150,570,1182));
        a.add(l("Customer drop-off",90,1196,420,1230));a.add(l("Accept",275,1335,406,1380));a.add(l(time,558,1343,625,1377));
        if(promo)a.add(l("Very busy +$2",60,240,330,300));return a;
    }
    public static void main(String[] args){
        String[][] screenshots={{"$11.27","2 stops (7.3 km) • 38 min","McDonald's","0:42","1127","38","7300"},{"$10.21","2 stops (7.8 km) • 32 min","McDonald's","0:23","1021","32","7800"},{"$8.58","2 stops (4.5 km) • 22 min","7-Eleven","0:32","858","22","4500"},{"$8.50","2 stops (3.2 km) • 26 min","McDonald's","0:33","850","26","3200"},{"$7.97","2 stops (4.3 km) • 23 min","McDonald's","0:38","797","23","4300"},{"$10.36","2 stops (5.3 km) • 33 min","McDonald's","0:32","1036","33","5300"}};
        for(String[] s:screenshots){DoorDashOffer.Read r=DoorDashOffer.parse(offer(s[0],s[1],s[2],s[3],s[0].equals("$8.58"),true));ok(r!=null,s[0]);ok(r.cents==Integer.parseInt(s[4])&&r.minutes==Integer.parseInt(s[5])&&r.metres==Integer.parseInt(s[6])&&r.count==1,s[0]+" metrics");ok(r.details().type.startsWith("DoorDash"),"platform history");}
        DoorDashOffer.Read a=DoorDashOffer.parse(offer("$7.97","2 stops (4.3 km) • 23 min","McDonald's","0:38",false,false));
        DoorDashOffer.Read b=DoorDashOffer.parse(offer("$7.97","2 stops (4.3 km) • 23 min","McDonald's","0:36",false,false));
        ok(DoorDashOffer.agrees(a,b,2000),"stable same offer");ok(!DoorDashOffer.agrees(b,a,2000),"timer increased");ok(!DoorDashOffer.agrees(a,b,5000),"stale frame");
        DoorDashOffer.Read stack=DoorDashOffer.parse(offer("$7.97","3 stops (4.3 km) • 23 min","McDonald's","0:38",false,false));ok(stack!=null&&stack.count==0,"stack unknown");
        ok(DoorDashOffer.parse(offer("$7.9","2 stops (4.3 km) • 23 min","McDonald's","0:38",false,false))==null,"truncated price");
        ok(DoorDashOffer.parse(offer("$7.97","2 stops (4.3 km) • 23 min","McDonald's","0:00",false,false))==null,"expired");
        List<OfferScreenEvaluator.Line> confirm=Arrays.asList(l("Are you sure you want to",30,726,570,770),l("decline this offer?",30,781,470,826),l("12%",286,990,390,1032),l("Decline offer",240,1210,455,1250),l("0:27",555,1215,625,1250),l("View offer details",205,1310,490,1355));
        DoorDashOffer.Confirmation c=DoorDashOffer.confirmation(confirm);ok(c!=null&&c.seconds==27&&c.target.text.equals("Decline offer"),"second stage");
        ok(DoorDashOffer.confirmation(offer("$7.97","2 stops (4.3 km) • 23 min","McDonald's","0:38",false,false))==null,"offer isn't confirmation");
        ok(DoorDashOffer.confirmation(confirm.subList(2,confirm.size()))==null,"cannot confirm without question");
        ok(OfferSurfacePolicy.shouldScan(OfferSurfacePolicy.Host.DOORDASH),"DoorDash enabled surface");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.DOORDASH,true,true,2,.99),"Uber X policy not reused for DD");
        System.out.println("DoorDash parser, six screenshot transcriptions, timer, stacked count and confirmation safety PASS");
    }
}
