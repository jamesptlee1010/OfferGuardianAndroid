package com.personal.offerguardian;
import java.util.*;
public final class DoorDashStabilityTest {
    static int n=0;
    static void ok(boolean result,String description){if(!result)throw new AssertionError(description);n++;}
    static OfferScreenEvaluator.Line l(String text,int x,int y,int r,int b){return new OfferScreenEvaluator.Line(text,x,y,r,b);}
    static List<OfferScreenEvaluator.Line> single(boolean decline,boolean timer){
        List<OfferScreenEvaluator.Line> lines=new ArrayList<>();
        if(decline)lines.add(l("Decline",510,91,640,125));
        lines.add(l("$13.01",30,835,244,904));lines.add(l("2 stops (5.6 km) • 25 min",30,943,510,979));
        lines.add(l("KFC Clayfield",92,1067,340,1102));lines.add(l("844 Sandgate Road && 4 Gellibrand...",92,1115,640,1148));
        lines.add(l("Customer drop-off",92,1190,450,1225));lines.add(l("Accept",260,1340,410,1382));
        if(timer)lines.add(l("0:35",550,1340,630,1382));return lines;
    }
    public static void main(String[] args){
        DoorDashOffer.Read r=DoorDashOffer.parse(single(true,true));ok(r!=null,"KFC screenshot parsed");
        ok(r.cents==1301&&r.minutes==25&&r.metres==5600&&r.count==1,"KFC exact values");
        OfferRuleEngine.Config hourly=new OfferRuleEngine.Config(false,0,true,30,false,0,OfferRuleEngine.Mode.ANY);
        OfferRuleEngine.Decision result=OfferRuleEngine.evaluate(hourly,r.cents/100.0,r.minutes,r.metres,r.count);
        ok(result.outcome==OfferRuleEngine.Outcome.SHOW,"$13.01 must qualify on hourly-only $30");
        ok(Math.abs(result.hourly-31.224)<.00001,"exact hourly");ok(Math.abs(result.perKm-2.3232142857)<.00001,"exact km");
        OfferRuleEngine.Config and=new OfferRuleEngine.Config(true,25,true,30,false,0,OfferRuleEngine.Mode.ALL);
        ok(OfferRuleEngine.evaluate(and,13.01,25,5600,1).outcome==OfferRuleEngine.Outcome.DECLINE,"AND additional price gate still respected");
        DoorDashOffer.Read covered=DoorDashOffer.parse(single(false,false));ok(covered!=null&&covered.target==null&&covered.seconds==-1,"covered button and timer don't prevent read-only rates");
        ok(DoorDashOffer.agrees(r,covered,800),"numeric identity remains stable when control covered");
        List<OfferScreenEvaluator.Line> stack=Arrays.asList(l("Decline",512,91,635,125),l("$16.03",30,620,246,688),l("3 stops (6.6 km) • 35 min",30,724,520,762),l("Burger Urge",92,850,340,884),l("Eats 2 U",92,976,260,1010),l("Customer drop-off",92,1100,450,1135),l("Drop off 2 orders",114,1180,370,1220),l("Accept",260,1340,410,1382),l("0:15",550,1340,630,1382));
        r=DoorDashOffer.parse(stack);ok(r!=null&&r.count==2&&r.cents==1603&&r.minutes==35&&r.metres==6600,"stacked screenshot explicit order count");
        ok(OfferRuleEngine.evaluate(hourly,16.03,35,6600,2).outcome==OfferRuleEngine.Outcome.DECLINE,"stack below $30/hr");
        List<OfferScreenEvaluator.Line> confirm=Arrays.asList(l("Are you sure you want to decline",30,729,630,777),l("this offer?",30,786,400,825),l("Decline offer",230,1210,450,1250),l("0:24",555,1210,630,1250));
        DoorDashOffer.Confirmation c=DoorDashOffer.confirmation(confirm);ok(c!=null&&c.seconds==24,"split heading and no details OCR line");
        ok(DoorDashOffer.confirmation(confirm.subList(0,3)).seconds==-1,"readable confirmation without timer");
        ok(DoorDashOffer.confirmation(confirm.subList(2,4))==null,"button alone cannot authorize confirm");
        ok(CrossPlatformPolicy.allowDashSwitch(OfferSurfacePolicy.Host.UBER,false,false,false),"unknown idle wording no longer blocks Uber");
        ok(CrossPlatformPolicy.allowDashSwitch(OfferSurfacePolicy.Host.OTHER,true,false,false),"other app enabled");
        ok(!CrossPlatformPolicy.allowDashSwitch(OfferSurfacePolicy.Host.OTHER,false,false,false),"respect other app opt-out");
        ok(!CrossPlatformPolicy.allowDashSwitch(OfferSurfacePolicy.Host.UBER,true,true,false),"known active delivery blocks");
        ok(!CrossPlatformPolicy.allowDashSwitch(OfferSurfacePolicy.Host.UBER,true,false,true),"competing action blocks");
        ok(CrossPlatformPolicy.activeDelivery("Confirm pickup"),"active marker");
        ok(!CrossPlatformPolicy.activeDelivery("Finding offers"),"waiting not active");
        System.out.println("DoorDash v2.4.0 stability: "+n+" assertions PASS");
    }
}
