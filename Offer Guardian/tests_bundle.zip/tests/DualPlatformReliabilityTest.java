package com.personal.offerguardian;
import java.util.*;
public final class DualPlatformReliabilityTest {
 static int n; static void ok(boolean b,String m){if(!b)throw new AssertionError(m);n++;}
 static OfferScreenEvaluator.Line l(String t,int x,int y,int r,int b){return new OfferScreenEvaluator.Line(t,x,y,r,b);}
 static List<OfferScreenEvaluator.Line> dd(String price,String metrics,String merchant,String drop,String timer,boolean accept,boolean decline){
  List<OfferScreenEvaluator.Line> a=new ArrayList<>(); if(decline)a.add(l("Decline",512,90,642,126));
  a.add(l(price,32,750,300,820));a.add(l(metrics,32,855,610,895));
  if(!merchant.isEmpty())a.add(l(merchant,95,980,620,1020));if(!drop.isEmpty())a.add(l(drop,95,1170,640,1210));
  if(accept)a.add(l("Accept",270,1350,420,1390));if(!timer.isEmpty())a.add(l(timer,560,1350,644,1390));return a;
 }
 static OfferRuleEngine.Config hourly=new OfferRuleEngine.Config(false,0,true,30,false,0,OfferRuleEngine.Mode.ANY);
 static DoorDashOffer.Read check(String price,String metrics,String merchant,String drop,int count,double rate,OfferRuleEngine.Outcome expected){
  DoorDashOffer.Read a=DoorDashOffer.parse(dd(price,metrics,merchant,drop,"0:27",true,true));ok(a!=null,price+" parsed");ok(a.count==count,price+" count");ok(a.actionIdentity,price+" identity");
  OfferRuleEngine.Decision d=OfferRuleEngine.evaluate(hourly,a.cents/100.0,a.minutes,a.metres,a.count);ok(Math.abs(d.hourly-rate)<.006,price+" rate "+d.hourly);ok(d.outcome==expected,price+" decision");return a;
 }
 public static void main(String[] args){
  DoorDashOffer.Read good=check("$6.71","2 stops (1.7 km) • 13 min","Burger Urge","Customer drop-off",1,30.97,OfferRuleEngine.Outcome.SHOW);
  check("$13.01","2 stops (5.6 km) • 25 min","KFC Clayfield","Customer drop-off",1,31.22,OfferRuleEngine.Outcome.SHOW);
  DoorDashOffer.Read stack=check("$16.51","4 stops (5.5 km) • 29 min","KFC Clayfield","Multiple drop-offs (2 stops)",2,34.16,OfferRuleEngine.Outcome.SHOW);
  check("$16.03","3 stops (6.6 km) • 35 min","Burger Urge","Drop off 2 orders",2,27.48,OfferRuleEngine.Outcome.DECLINE);
  DoorDashOffer.Read bad=DoorDashOffer.parse(dd("$6.71","2 stops (1.7 km) • 14 min","Burger Urge","Customer drop-off","0:26",true,true));
  ok(bad!=null&&!DoorDashOffer.agrees(good,bad,1000),"different minutes");ok(OfferDecisionProtection.sameVisibleDash(good,bad,1000),"protect prior qualifying read");
  ok(OfferDecisionProtection.nearHourly(hourly,OfferRuleEngine.evaluate(hourly,6.71,14,1700,1)),"near hourly");ok(!OfferDecisionProtection.nearHourly(hourly,OfferRuleEngine.evaluate(hourly,5,30,1700,1)),"far below");
  DoorDashOffer.Read a=DoorDashOffer.parse(dd("$13.01","2 stops (5.6 km) • 25 min","","Customer drop-off","",false,true));ok(a!=null&&a.count==1&&!a.actionIdentity,"financial only no merchant or accept");
  a=DoorDashOffer.parse(dd("$13.01","2 stops (5.6 km) • 25 min","KFC","","0:22",true,true));ok(a!=null&&a.count==0&&!a.actionIdentity,"unknown count");
  List<OfferScreenEvaluator.Line> conflict=dd("$16.51","4 stops (5.5 km) • 29 min","KFC","Multiple drop-offs (2 stops)","0:25",true,true);conflict.add(l("Drop off 3 orders",95,1220,430,1250));a=DoorDashOffer.parse(conflict);ok(a!=null&&a.count==0&&!a.actionIdentity,"conflicting count");ok(!OfferDecisionProtection.sameVisibleDash(good,stack,1000),"different order");
  UberDeclineRetry r=new UberDeclineRetry();r.observe("a",1000);ok(r.ready(1000)&&r.attempt(1000)==1,"first");ok(!r.ready(1100),"cooldown");r.observe("changed",1500);ok(!r.ready(1500),"OCR cannot reset retry");ok(r.ready(1600)&&r.attempt(1600)==2,"second");ok(r.ready(2200)&&r.attempt(2200)==3,"third");ok(!r.canAttempt(),"limit");r.observe("c",2400);ok(!r.canAttempt(),"continuous card");ok(r.canFallback(),"fallback available");r.fallback();ok(!r.canFallback(),"fallback once");r.reset();r.observe("new",3000);ok(r.canAttempt()&&r.canFallback(),"new session");
  VisualDeclineDetector.Match v=new VisualDeclineDetector.Match(true,579,650,.98,"fixture",VisualDeclineDetector.Theme.LIGHT,570);
  List<OfferScreenEvaluator.Line> uber=Arrays.asList(l("Delivery Exclusive",75,620,430,654),l("$13.09",61,690,310,755),l("Est. earnings for completed trip",75,789,550,825),l("29 min (10.7 km) total",120,908,550,945),l("Halfpint Kitchen",128,996,560,1035),l("Kangaroo Point",128,1085,550,1125),l("Accept",320,1300,440,1350));
  ok(OfferScreenEvaluator.offerKind(v,uber).equals("Exclusive"),"exclusive");ok(OfferScreenEvaluator.hasOfferIdentity(v,uber),"identity");ok(OfferScreenEvaluator.assess(v,uber).valid,"payout");OfferDetailsParser.Details d=OfferDetailsParser.parse(v.y,uber);ok(d.minutes==29&&d.deliveryCount==1,"details");ok(OfferRuleEngine.evaluate(hourly,13.09,29,10700,1).outcome==OfferRuleEngine.Outcome.DECLINE,"decline 13.09");
  List<OfferScreenEvaluator.Line> financeOnly=new ArrayList<>(uber.subList(0,4));financeOnly.add(l("Accept",320,1300,440,1350));
  OfferDetailsParser.Details only=OfferDetailsParser.parse(v.y,financeOnly);ok(OfferExtractionGuard.checkFinancial(only).valid,"independent financial read");ok(!OfferExtractionGuard.check(only).valid,"merchant remains required for decline");
  List<OfferScreenEvaluator.Line> radar=new ArrayList<>(uber);radar.set(0,l("Delivery",75,620,230,654));radar.set(radar.size()-1,l("Match",320,1300,440,1350));ok(OfferScreenEvaluator.offerKind(v,radar).equals("Trip Radar"),"radar");ok(!CrossPlatformPolicy.allowUberDecline(OfferSurfacePolicy.Host.DOORDASH,false,true,.99),"no unknown-owner tap");ok(CrossPlatformPolicy.allowUberDecline(OfferSurfacePolicy.Host.DOORDASH,true,true,.99),"verified overlay tap");ok(OfferRuleEngine.evaluate(hourly,5,11,3100,1).outcome==OfferRuleEngine.Outcome.DECLINE,"whole-dollar decline");
  System.out.println("v2.5.0 reliability: "+n+" assertions PASS");
 }
}
