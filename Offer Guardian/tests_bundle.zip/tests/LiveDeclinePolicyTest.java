package com.personal.offerguardian;
public class LiveDeclinePolicyTest {
    static int n;static void c(boolean b){n++;if(!b)throw new AssertionError(n);}
    public static void main(String[] args){
        String focus="mCurrentFocus=Window{abcd u0 com.ubercab.driver/.MainActivity}";
        c(LiveDeclinePolicy.focusIsUber(focus));c(!LiveDeclinePolicy.focusIsUber(focus+"\nmCurrentFocus=null"));c(!LiveDeclinePolicy.focusIsUber("mCurrentFocus=Window{1 u0 com.ubercab.driver.fake/.MainActivity}"));c(!LiveDeclinePolicy.focusIsUber("mCurrentFocus=Window{1 u0 com.other/.MainActivity}"));c(!LiveDeclinePolicy.focusIsUber(null));
        c(LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,100,2000));
        c(!LiveDeclinePolicy.valid(0,10001,10001,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10002,10001,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,-1,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,720,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,1570,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,2000,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,100,2001));
        String oppo="  mCurrentFocus=Window{346375f u0 com.ubercab.driver/com.ubercab.carbon.core.CarbonActivity}\n  mFocusedApp=ActivityRecord{118975628 u0 com.ubercab.driver/com.ubercab.carbon.core.CarbonActivity t33}";
        c(LiveDeclinePolicy.focusIsUber(oppo));
        c(LiveDeclinePolicy.focus("")==LiveDeclinePolicy.Focus.MISSING);
        c(LiveDeclinePolicy.focus("mCurrentFocus=null")==LiveDeclinePolicy.Focus.UNVERIFIED);
        c(LiveDeclinePolicy.focus(oppo+"\nmCurrentFocus=Window{12 u0 com.other/.Main}")==LiveDeclinePolicy.Focus.UNVERIFIED);
        c(LiveDeclinePolicy.focus(oppo+"\n"+oppo)==LiveDeclinePolicy.Focus.UNVERIFIED);
        c(LiveDeclinePolicy.primaryQuery(36).equals("displays"));
        c(LiveDeclinePolicy.primaryQuery(35).equals("windows"));
        c(LiveDeclinePolicy.primaryQuery(34).equals("windows"));
        c(LiveDeclinePolicy.alternateQuery("displays").equals("windows"));
        c(LiveDeclinePolicy.alternateQuery("windows").equals("displays"));
        System.out.println("Live decline guard: "+n+" assertions passed");
    }
}
