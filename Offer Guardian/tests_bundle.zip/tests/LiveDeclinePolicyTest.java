package com.personal.offerguardian;
public class LiveDeclinePolicyTest {
    static int n;static void c(boolean b){n++;if(!b)throw new AssertionError(n);}
    public static void main(String[] args){
        String focus="mCurrentFocus=Window{abcd u0 com.ubercab.driver/.MainActivity}";
        c(LiveDeclinePolicy.focusIsUber(focus));c(!LiveDeclinePolicy.focusIsUber(focus+"\nmCurrentFocus=null"));c(!LiveDeclinePolicy.focusIsUber("mCurrentFocus=Window{1 u0 com.ubercab.driver.fake/.MainActivity}"));c(!LiveDeclinePolicy.focusIsUber("mCurrentFocus=Window{1 u0 com.other/.MainActivity}"));c(!LiveDeclinePolicy.focusIsUber(null));
        c(LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,100,2000));
        c(!LiveDeclinePolicy.valid(0,10001,10001,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10002,10001,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,-1,608,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,720,724,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,1570,720,1570,100,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,2000,2000));c(!LiveDeclinePolicy.valid(2000,10001,10001,608,724,720,1570,100,2001));
        System.out.println("Live decline guard: "+n+" assertions passed");
    }
}
