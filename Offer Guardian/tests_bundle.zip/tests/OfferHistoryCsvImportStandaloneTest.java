import com.personal.offerguardian.OfferHistoryCsvImport;
import java.io.FileReader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class OfferHistoryCsvImportStandaloneTest {
    private static void ok(boolean success,String msg) {if(!success)throw new AssertionError(msg);}
    private static final String OLD_HEADER="Offer time,Estimated payout AUD,Type,Pickup,Destination shown,Estimated minutes,Estimated km,Estimated AUD per km,Estimated AUD per hour,Outcome,Automation action\n";
    private static final String NEW_HEADER="Offer time,Estimated payout AUD,Type,Delivery count,Pickup,Destination shown,Estimated minutes,Estimated km,Estimated AUD per km,Estimated AUD per hour,Outcome,Automation action,Raw payout OCR,Raw duration OCR,Raw distance OCR,Extraction status,Extraction note,Verified frames,Parsed hours,Parsed minute component\n";
    public static void main(String[] args)throws Exception {
        List<OfferHistoryCsvImport.Entry> rows=new ArrayList<>();
        String old="\uFEFF"+OLD_HEADER+
            "\"2026-11-22 12:30:29\",\"29.66\",\"Pack & Deliver\",\"Coles (Kedron)\",\"Kate Street & Mellor Street, Kedron\",\"7\",\"9.8\",\"A$3.03/km\",\"A$254.23/hr\",\"UNKNOWN\",\"NONE\"\r\n"+
            "\"2026-11-22 12:29:07\",\"9.32\",\"Delivery\",\"Chickadoo \"\"Chicken &\"\"\",\"Burgers\"\" Hadley Street\",\"21\",\"8.5\",\"A$1.10/km\",\"A$26.63/hr\",\"UNKNOWN\",\"DECLINE_REQUESTED\"\r\n";
        OfferHistoryCsvImport.Report r=OfferHistoryCsvImport.read(new StringReader(old),rows::add);
        ok(r.rows==2&&r.invalid==0&&rows.size()==2,"old CSV parse");
        ok(rows.get(0).seenAt>0&&rows.get(0).payoutCents==2966,"date and cents");
        ok(rows.get(0).minutes==7&&rows.get(0).metres==9800,"duration and km");
        ok("LEGACY_UNVERIFIED".equals(rows.get(0).extractionStatus),"must not trust old $254/hr");
        ok(rows.get(0).deliveryCount==0,"generic Pack & Deliver count unknown");
        ok(rows.get(1).pickup.contains("\"Chicken &\""),"double escaped quotes must survive");
        rows.clear();
        String newer=NEW_HEADER+
            "\"2026-11-23 18:18:00\",\"30.59\",\"Pack & Deliver (3)\",\"3\",\"Coles\",\"Somewhere\",\"56\",\"9.8\",\"A$3.12/km\",\"A$32.78/hr\",\"DECLINED\",\"DECLINE_REQUESTED\",\"$30.59\",\"56 min\",\"9.8 km\",\"VERIFIED\",\"Two matching readings\",\"2\",\"0\",\"56\"\n"+
            "\"2026-11-23 18:19:00\",\"11.34\",\"Delivery (2)\",\"2\",\"Dessert Station\",\"Destination\",\"\",\"\",\"\",\"\",\"UNKNOWN\",\"NONE\",\"\",\"\",\"\",\"COUNT_ONLY\",\"Two matching delivery headings confirm 2 deliveries.\",\"2\",\"0\",\"0\"\n";
        r=OfferHistoryCsvImport.read(new StringReader(newer),rows::add);
        ok(r.rows==2&&r.invalid==0,"new CSV parse");
        ok(rows.get(0).deliveryCount==3 && rows.get(1).deliveryCount==2,"explicit delivery count");
        ok("VERIFIED".equals(rows.get(0).extractionStatus),"verified status preserved");
        ok("COUNT_ONLY".equals(rows.get(1).extractionStatus),"count only status preserved");
        ok("DECLINED".equals(rows.get(0).outcome),"outcome preserved");
        rows.clear();
        String invalid=OLD_HEADER+"\"not a timestamp\",12.00,Delivery,Test,Dest,10,1.2,,,UNKNOWN,NONE\n"+
            "\"2026-11-22 12:50:00\",12.00,Delivery,Test,Dest,10,1.2,,,UNKNOWN,NONE\n";
        r=OfferHistoryCsvImport.read(new StringReader(invalid),rows::add);
        ok(r.invalid==1 && rows.size()==1,"invalid row skipped, later row survives");
        try {OfferHistoryCsvImport.read(new StringReader("wrong,header\nfoo,bar\n"),rows::add);
             throw new AssertionError("wrong header must fail");}
        catch(java.io.IOException expected) {}
        try {OfferHistoryCsvImport.read(new StringReader(OLD_HEADER+"\"unterminated"),rows::add);
             throw new AssertionError("broken quoted CSV must fail");}
        catch(java.io.IOException expected) {}
        if(args.length>0) {
            rows.clear();
            try(FileReader f=new FileReader(args[0],StandardCharsets.UTF_8)) {
                r=OfferHistoryCsvImport.read(f,rows::add);
                ok(r.rows>50, "actual legacy CSV should contain many records");
                ok(r.invalid==0,"actual legacy CSV should decode cleanly: "+r.invalid);
                System.out.println("Real legacy CSV: "+r.rows+" rows decoded");
            }
        }
        System.out.println("OfferHistoryCsvImportStandaloneTest PASS");
    }
}
