package com.personal.offerguardian;

/** Exports the actual production SQL condition for SQLite integration regression tests. */
public final class OfferHistoryTimeWindowSqlDump {
    public static void main(String[] args) {
        if(args.length==3 && "schedule".equals(args[0])) {
            OfferHistoryTimeWindow.Sql filter=new OfferHistoryTimeWindow.Schedule(
                Integer.parseInt(args[1]),Integer.parseInt(args[2])).toSql();
            System.out.println(filter.where);
            System.out.println(String.join(",",filter.args));
            return;
        }
        int start=Integer.parseInt(args[0]),end=Integer.parseInt(args[1]);
        OfferHistoryTimeWindow.Sql sql=new OfferHistoryTimeWindow(true,start,end).toSql();
        System.out.println(sql.where);
    }
}
