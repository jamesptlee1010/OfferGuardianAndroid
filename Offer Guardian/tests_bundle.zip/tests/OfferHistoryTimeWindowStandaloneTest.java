package com.personal.offerguardian;

public final class OfferHistoryTimeWindowStandaloneTest {
    static int checks;
    static void ok(boolean v,String message){checks++;if(!v)throw new AssertionError(message);}
    public static void main(String[] args){
        OfferHistoryTimeWindow day=new OfferHistoryTimeWindow(true,17*60,20*60);
        ok(day.matchesLocalMinute(17*60),"5 pm inclusive");
        ok(day.matchesLocalMinute(19*60+59),"7:59 pm included");
        ok(day.matchesLocalMinute(20*60),"8 pm inclusive");
        ok(!day.matchesLocalMinute(16*60+59),"4:59 pm excluded");
        ok(!day.matchesLocalMinute(20*60+1),"8:01 pm excluded");
        ok(day.summary().equals("5:00 pm–8:00 pm"),"display");
        ok(day.toSql().where.contains(" AND "),"SQL daytime AND");
        ok(day.toSql().args.size()==2,"bound args");
        OfferHistoryTimeWindow night=new OfferHistoryTimeWindow(true,22*60,2*60);
        ok(night.matchesLocalMinute(23*60+59),"11:59 pm included");
        ok(night.matchesLocalMinute(0),"midnight included");
        ok(night.matchesLocalMinute(2*60),"2 am included");
        ok(!night.matchesLocalMinute(12*60),"noon excluded");
        ok(night.toSql().where.contains(" OR "),"overnight SQL OR");
        ok(OfferHistoryTimeWindow.disabled().matchesLocalMinute(12*60),"disabled all day");
        ok(!OfferHistoryTimeWindow.disabled().enabled,"disabled flag");
        ok(new OfferHistoryTimeWindow(true,7,7).matchesLocalMinute(7),"single minute inclusive");
        ok(!new OfferHistoryTimeWindow(true,7,7).matchesLocalMinute(8),"single minute excludes others");
        try{new OfferHistoryTimeWindow(true,1440,0);throw new AssertionError("must reject 1440");}
        catch(IllegalArgumentException expected){checks++;}
        // v0.9.12: weekday and shift quick filters (half-open time bands).
        OfferHistoryTimeWindow.Schedule base=OfferHistoryTimeWindow.Schedule.any();
        ok(base.matches(1,0)&&base.matches(7,1439),"All weekdays and periods");
        OfferHistoryTimeWindow.Schedule monday=base.withWeekday(1);
        ok(monday.matches(1,12*60),"Monday accepted");
        ok(!monday.matches(2,12*60),"Tuesday rejected when Monday selected");
        ok(monday.toSql().where.contains("strftime('%w'"),"Monday uses local weekday");
        OfferHistoryTimeWindow.Schedule evening=monday.togglePeriod(OfferHistoryTimeWindow.Schedule.EVENING);
        ok(evening.matches(1,17*60),"Evening starts 5pm");
        ok(evening.matches(1,21*60+29),"9:29pm evening");
        ok(!evening.matches(1,21*60+30),"9:30pm no longer evening");
        ok(!evening.matches(2,18*60),"Other weekdays excluded");
        OfferHistoryTimeWindow.Schedule nightShift=base.togglePeriod(OfferHistoryTimeWindow.Schedule.NIGHT);
        ok(nightShift.matches(2,0),"Tuesday midnight belongs to Tuesday night");
        ok(nightShift.matches(2,5*60+59),"5:59am night");
        ok(!nightShift.matches(2,6*60),"6am excluded from night");
        ok(nightShift.matches(1,21*60+30),"9:30pm night");
        ok(!nightShift.matches(1,21*60+29),"9:29pm excluded from night");
        OfferHistoryTimeWindow.Schedule both=evening.togglePeriod(OfferHistoryTimeWindow.Schedule.NIGHT);
        ok(both.matches(1,22*60),"Multi-select includes night");
        ok(both.matches(1,20*60),"Multi-select includes evening");
        ok(!both.matches(1,14*60),"Multi-select excludes afternoon");
        ok(both.togglePeriod(OfferHistoryTimeWindow.Schedule.EVENING).periodMask==16,"Tap toggles off selected shift");
        ok(nightShift.togglePeriod(OfferHistoryTimeWindow.Schedule.NIGHT).periodMask==0,"Tap second time resets to all");
        ok(nightShift.summary().contains("Night"),"Summary describes shift");
        ok(new OfferHistoryTimeWindow.Schedule(7,0).toSql().args.get(0).equals("0"),"Sunday SQLite index zero");
        for(int i=0;i<1440;i++) {
            int count=0;
            for(int bit=1;bit<=16;bit<<=1)if(base.togglePeriod(bit).matches(1,i))count++;
            ok(count==1,"No overlap or gap at minute "+i);
        }
        try {new OfferHistoryTimeWindow.Schedule(8,0);throw new AssertionError("bad day");}
        catch(IllegalArgumentException expected){checks++;}
        try {new OfferHistoryTimeWindow.Schedule(0,32);throw new AssertionError("bad period");}
        catch(IllegalArgumentException expected){checks++;}
        System.out.println("OfferHistoryTimeWindow: "+checks+" assertions passed");
    }
}
