package com.personal.offerguardian;

public final class OfferScanWatchdogStandaloneTest {
    private static int count=0;
    private static void ok(boolean condition,String msg) {
        count++;if(!condition)throw new AssertionError(msg);
    }
    public static void main(String[] args) {
        OfferScanWatchdog w=new OfferScanWatchdog();
        ok(!w.busy(),"initially idle");
        long first=w.begin(1000);
        ok(first>0 && w.busy() && w.owns(first),"begin owns active token");
        ok(w.safeToProcess(first,8999,8000),"under 8s deadline permits processing");
        ok(!w.overdue(8999,8000),"deadline not elapsed");
        ok(w.overdue(9000,8000),"8s deadline elapsed exactly");
        ok(!w.safeToProcess(first,9000,8000),"stale OCR blocked at deadline");
        ok(w.recover(9000,8000)==first,"recover invalidates first capture");
        ok(!w.busy() && w.recoveries()==1,"watchdog idle with recovery count");
        ok(!w.finish(first,9001),"late screenshot cannot finish new generation");
        long second=w.begin(9500);
        ok(second!=first && w.owns(second),"second capture token unique");
        ok(!w.safeToProcess(first,9501,8000),"late success cannot process OCR/tap");
        ok(!w.finish(first,9600) && w.busy(),"late completion cannot clear new busy state");
        ok(w.safeToProcess(second,9600,8000),"new scan can process normally");
        ok(w.finish(second,9711),"fresh scan finishes");
        ok(!w.busy() && w.lastFinishedAt()==9711,"finish returns idle with timestamp");
        ok(w.recover(50000,8000)==0,"idle never recovers spuriously");
        long third=w.begin(50100);
        w.invalidate();
        ok(!w.owns(third) && !w.safeToProcess(third,50101,8000),"service unbind invalidates old OCR");
        long fourth=w.begin(51000);
        ok(fourth!=third && w.finish(fourth,51001),"restart permits fresh scan");
        System.out.println("OfferScanWatchdog: " + count + " assertions PASSED");
    }
}
