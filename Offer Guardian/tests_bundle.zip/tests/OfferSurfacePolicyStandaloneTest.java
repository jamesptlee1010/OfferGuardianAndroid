package com.personal.offerguardian;

/** Uber-only foreground guard regression tests; no Android dependencies. */
public final class OfferSurfacePolicyStandaloneTest {
    private static void ok(boolean pass,String description) {
        if(!pass)throw new AssertionError(description);
    }
    public static void main(String[] args) {
        ok(OfferSurfacePolicy.classify("com.ubercab.driver")==OfferSurfacePolicy.Host.UBER,"Uber host");
        ok(OfferSurfacePolicy.classify("com.waze")==OfferSurfacePolicy.Host.OTHER,"Navigation apps are not monitored");
        ok(!OfferSurfacePolicy.shouldScan(OfferSurfacePolicy.classify("com.example.random")),"Other apps ignored");
        ok(OfferSurfacePolicy.shouldScan(OfferSurfacePolicy.Host.UBER),"Uber remains monitored");
        ok(OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.UBER,true,true,2,.96),"Verified Uber card allowed");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.OTHER,true,true,2,.99),"Other apps never decline");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.UBER,false,true,2,.99),"Missing card never declines");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.UBER,true,true,2,.89),"Weak X never declines");
        System.out.println("Uber-only foreground and decline safety policy PASS (8 tests)");
    }
}
