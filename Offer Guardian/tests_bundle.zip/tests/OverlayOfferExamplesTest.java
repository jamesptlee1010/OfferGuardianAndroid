package com.personal.offerguardian;
import java.util.*;
public final class OverlayOfferExamplesTest {
    static OfferScreenEvaluator.Line line(String s,int left,int y,int right,int height){return new OfferScreenEvaluator.Line(s,left,y,right,y+height);}
    static void check(int y,String header,String price,String metrics,String merchant,String destination,int mins,int metres,double pay,int items){
        VisualDeclineDetector.Match v=new VisualDeclineDetector.Match(true,579,y,.98,"fixture",VisualDeclineDetector.Theme.LIGHT,y-78);
        List<OfferScreenEvaluator.Line> lines=new ArrayList<>();
        lines.add(line(header,110,y-27,340,34));lines.add(line(price,62,y+35,315,65));lines.add(line("Est. earnings for completed trip",75,y+139,548,34));
        if(items>0)lines.add(line("20 items (25 units)",120,y+238,410,34));
        int my=y+(items>0?340:233);lines.add(line(metrics,120,my,460,35));
        lines.add(line(merchant,128,my+95,590,40));lines.add(line(destination,128,my+185,610,38));
        lines.add(line("Accept",320,1300,445,34));
        if(!OfferScreenEvaluator.hasOfferIdentity(v,lines))throw new AssertionError("identity "+price);
        OfferScreenEvaluator.Assessment a=OfferScreenEvaluator.assess(v,lines);
        OfferDetailsParser.Details d=OfferDetailsParser.parse(y,lines);
        if(!a.valid||Math.abs(a.payout-pay)>.001||d.minutes!=mins||d.metres!=metres||d.deliveryCount!=1||d.itemCount!=items)throw new AssertionError("metrics "+price+" "+a.reason+" "+d.minutes+" "+d.metres+" count="+d.deliveryCount+" items="+d.itemCount);
    }
    public static void main(String[] a){
        check(620,"Pack & Deliver Exclusive","$22.09","49 min (8.9 km) total","Coles (Lutwyche)","Laisby Drive & Mulgrave Street, Spring Hill",49,8900,22.09,20);
        check(653,"Delivery Exclusive","$18.08","41 min (19.6 km) total","Bong Chicken&Beer","Audenshaw Street & Gladstone Road, Highgate Hill",41,19600,18.08,0);
        check(612,"Delivery Exclusive","$9.06","18 min (2.7 km) total","Woolworths Nundah","Alexandra Road & Vine Street, Clayfield",18,2700,9.06,0);
        check(708,"Delivery Exclusive","$7.04","15 min (5.0 km) total","7-Eleven (Northgate)","Buckland Road & Toombul Terrace, Nundah",15,5000,7.04,0);
        System.out.println("Overlay offer OCR-text fixtures: 4/4 PASS");
    }
}
