package com.personal.offerguardian;
public final class OwnTouchProbePolicyTest {
    static int n;
    static void check(boolean b){n++;if(!b)throw new AssertionError("test "+n);}
    public static void main(String[] args){
        String ok="  mCurrentFocus=Window{0123 u0 com.personal.offerguardian/.ShizukuDiagnosticsActivity}\n";
        String full="mCurrentFocus=Window{0123 u0 com.personal.offerguardian/com.personal.offerguardian.ShizukuDiagnosticsActivity}\n";
        check(OwnTouchProbePolicy.ownFocus(ok));check(OwnTouchProbePolicy.ownFocus(full));
        check(!OwnTouchProbePolicy.ownFocus("mCurrentFocus=null"));check(!OwnTouchProbePolicy.ownFocus(null));
        check(!OwnTouchProbePolicy.ownFocus("mCurrentFocus=Window{0123 u0 com.ubercab.driver/.MainActivity}"));
        check(!OwnTouchProbePolicy.ownFocus("mCurrentFocus=Window{0123 u0 com.personal.offerguardian/.MainActivity}"));
        check(!OwnTouchProbePolicy.ownFocus(ok+ok));check(!OwnTouchProbePolicy.ownFocus("mFocusedApp="+ok.substring(ok.indexOf("Window"))));
        check(OwnTouchProbePolicy.allowed(2000,10034,10034,300,400,ok));
        check(!OwnTouchProbePolicy.allowed(0,10034,10034,300,400,ok));check(!OwnTouchProbePolicy.allowed(2000,10035,10034,300,400,ok));
        check(!OwnTouchProbePolicy.allowed(2000,2000,2000,300,400,ok));check(!OwnTouchProbePolicy.allowed(2000,10034,10034,-1,400,ok));
        check(!OwnTouchProbePolicy.allowed(2000,10034,10034,300,10000,ok));
        check(OwnTouchProbePolicy.verified(1,1,1,0));check(!OwnTouchProbePolicy.verified(0,0,1,0));check(!OwnTouchProbePolicy.verified(1,1,1,1));check(!OwnTouchProbePolicy.verified(2,2,2,0));
        System.out.println(n+" own-screen probe assertions passed");
    }
}
