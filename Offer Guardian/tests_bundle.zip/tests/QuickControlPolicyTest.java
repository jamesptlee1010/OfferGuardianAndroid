package com.personal.offerguardian;
class QuickControlPolicyTest {
    static int count=0;
    static void check(boolean b){if(!b)throw new AssertionError("case "+count);count++;}
    public static void main(String[] args){
        String[] in={"This dash Finding offers.. You're more likely to get offers at hotspots. Zone offer wait", "Current dash Pause orders Earnings This dash Dash ends at 3:30 am", "Dash Paused Resume dash End Dash", "2 stops Customer drop-off Accept offer", "Current dash Pause orders This dash Dash ends at 3:30 am Complete delivery", "unrelated screen"};
        QuickControlPolicy.Screen[] out={QuickControlPolicy.Screen.IDLE,QuickControlPolicy.Screen.MENU,QuickControlPolicy.Screen.PAUSED,QuickControlPolicy.Screen.UNKNOWN,QuickControlPolicy.Screen.UNKNOWN,QuickControlPolicy.Screen.UNKNOWN};
        for(int i=0;i<in.length;i++)check(QuickControlPolicy.screen(in[i])==out[i]);
        check(QuickControlPolicy.screen("Dash Paused 34:48 You won't get offers while you're paused Resume dash End Dash")==QuickControlPolicy.Screen.PAUSED);
        check(QuickControlPolicy.screen("Dash Paused 32:58 You won't get offers while you're paused Resume dash End Dash")==QuickControlPolicy.Screen.PAUSED);
        check(QuickControlPolicy.resumeDecision(out[2],false)==QuickControlPolicy.ResumeDecision.CLICK);
        check(QuickControlPolicy.resumeDecision(out[2],true)==QuickControlPolicy.ResumeDecision.WAIT);
        check(QuickControlPolicy.resumeDecision(out[0],false)==QuickControlPolicy.ResumeDecision.ALREADY_ACTIVE);
        check(QuickControlPolicy.resumeDecision(out[0],true)==QuickControlPolicy.ResumeDecision.VERIFIED);
        check(QuickControlPolicy.resumeDecision(out[1],false)==QuickControlPolicy.ResumeDecision.WAIT);
        check(QuickControlPolicy.resumeDecision(out[3],false)==QuickControlPolicy.ResumeDecision.WAIT);
        check(QuickControlPolicy.resumeDecision(out[5],true)==QuickControlPolicy.ResumeDecision.WAIT);
        check(QuickControlPolicy.screen("Dash Paused End Dash")==QuickControlPolicy.Screen.UNKNOWN);
        System.out.println(count+" quick control screen and DR tests passed");
    }
}
