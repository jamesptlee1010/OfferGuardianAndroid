package com.personal.offerguardian;
class QuickDragPolicyTest {
    static int count=0;
    static void check(boolean b){if(!b)throw new AssertionError("case "+count);count++;}
    public static void main(String[] args){
        check(QuickDragPolicy.clamp(-10,100)==0);
        check(QuickDragPolicy.clamp(120,100)==100);
        check(QuickDragPolicy.clamp(20,-5)==0);
        check(QuickDragPolicy.position(.5f,200)==100);
        check(QuickDragPolicy.position(.5f,400)==200);
        check(QuickDragPolicy.position(1.5f,200)==200);
        check(QuickDragPolicy.position(Float.NaN,200)==0);
        check(QuickDragPolicy.fraction(75,100)==.75f);
        check(QuickDragPolicy.fraction(75,0)==0);
        check(QuickDragPolicy.mayTap(false,false,false));
        check(!QuickDragPolicy.mayTap(true,false,false));
        check(!QuickDragPolicy.mayTap(false,true,false));
        check(!QuickDragPolicy.mayTap(true,true,false));
        check(!QuickDragPolicy.mayTap(false,false,true));
        System.out.println(count+" drag geometry and tap suppression tests passed");
    }
}
