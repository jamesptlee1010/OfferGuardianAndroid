package com.personal.offerguardian;
import java.util.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
public class Reset300Test {
 static int[] pixels(File f,int w,int h)throws Exception{BufferedImage src=ImageIO.read(f),dst=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D g=dst.createGraphics();g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);g.drawImage(src,0,0,w,h,null);g.dispose();return dst.getRGB(0,0,w,h,null,0,w);}
 public static void main(String[] args)throws Exception{
 int[] light=pixels(new File("app/src/main/res/raw/decline_x_reference.png"),41,41),dark=pixels(new File("app/src/main/res/raw/decline_x_reference_dark.png"),41,41);
 int[] ids={195,194,193,192,187,186,185};String[] prices={"$8.65","$7.49","$31.99","$12.01","$18.03","$19.03","$18.07"};String[] heads={"Delivery","Delivery","Package","Delivery","Delivery (2)","Pack & Deliver","Pack & Deliver"};int[] mins={19,17,55,26,31,42,40};String[] km={"4.7","4.1","47.1","6.4","7.8","7.9","8.8"};
 for(int i=0;i<ids.length;i++){VisualDeclineDetector.Match m=VisualDeclineDetector.locateNear(pixels(new File(args[0],ids[i]+".jpg"),686,1536),686,1536,light,dark,41,41,-1);if(!m.found)throw new AssertionError("X not found "+ids[i]);int y=m.y;List<OfferScreenEvaluator.Line> lines=Arrays.asList(new OfferScreenEvaluator.Line(heads[i],70,y-18,300,y+10),new OfferScreenEvaluator.Line(prices[i],60,y+35,300,y+90),new OfferScreenEvaluator.Line("Est. earnings for completed trip",60,y+120,540,y+150),new OfferScreenEvaluator.Line(mins[i]+" min ("+km[i]+" km) total",90,y+220,500,y+250));OfferScreenEvaluator.Assessment a=OfferScreenEvaluator.assess(m,lines);OfferDetailsParser.Details d=OfferDetailsParser.parse(y,lines);if(!a.valid||!OfferScreenEvaluator.hasOfferIdentity(m,lines)||d.minutes!=mins[i]||d.deliveryCount!=(i==4?2:1))throw new AssertionError("text fixture "+ids[i]+" "+d.minutes+" "+d.deliveryCount);System.out.println(ids[i]+": X "+m.x+","+m.y+"; text fixture passed");}
 }
}
