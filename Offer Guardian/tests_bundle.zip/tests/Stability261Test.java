package com.personal.offerguardian;
import java.util.Arrays;
final class Stability261Test {
    private static int count;
    static void ok(boolean v,String s){count++;if(!v)throw new AssertionError(s);}
    static OfferScreenEvaluator.Line l(String s,int y){return new OfferScreenEvaluator.Line(s,62,y,600,y+30);}
    static OfferDetailsParser.Details details(String duration){return OfferDetailsParser.parse(522,Arrays.asList(l("Delivery",500),l("$33.03",570),l("Est. earnings for completed trip",640),l(duration,700),l("Hungry Jacks",820),l("Some Street, Windsor",920)));}
    static boolean same(String typeB,int amount,int mins,int metres,int count,String merchant,String dest,long age){return OfferHistoryDedup.same(age,"Delivery",typeB,4670,amount,21,mins,9000,metres,1,count,"HungryJacks (Herston)",merchant,"Brown Street & Hooker Street, Windsor",dest);}
    public static void main(String[] args){
        for(String raw:new String[]{") l hr l min (9.4 km) total",") lhr lmin (9,4 km) total",") l hrl min (9,4 km) total",") I hr I min (9.4 km) total"}){
            OfferDetailsParser.Details d=details(raw);ok(d.minutes==61&&d.metres==9400,raw+" parsed as "+d.minutes+" / "+d.metres);ok(OfferExtractionGuard.check(d).valid,"corrected duration passes");ok(d.rawDuration.equals(raw),"raw preserved");
        }
        ok(!OfferExtractionGuard.check(details("1 hr (9.4 km) total")).valid,"partial hour stays uncertain");
        ok(details("O 22 min (3.4 km) total").minutes==22,"clock artifact not hour");
        ok(same("Delivery",4670,21,9000,1,"YP Hungry Jacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"OCR prefix");
        ok(same("Delivery",4670,21,9000,1,"Hungry.Jacks (Herston)","Brown Street & Hooker Street, Windsor",3000),"punctuation");
        ok(OfferHistoryDedup.merchantSimilar("P Guzman y Gomez (Bowen","Y Guzman y Gomez (Bowen"),"GYG prefix variation");
        ok(OfferHistoryDedup.merchantSimilar("P Guzman y Gomez (Bowen","Guzmany Gomez (Bowen"),"GYG space variation");
        ok(!same("DoorDash · Delivery",4670,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"platform distinct");
        ok(!same("Delivery",4671,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"payout distinct");
        ok(!same("Delivery",4670,22,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"time distinct");
        ok(!same("Delivery",4670,21,9100,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"distance distinct");
        ok(!same("Delivery",4670,21,9000,2,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"count distinct");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","Other Road, Windsor",1000),"destination distinct");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","",1000),"missing destination");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",61000),"separate time");
        ok(!DoorDashPendingPolicy.allowIdentityReset(1,false),"changed OCR cannot reset pending first tap");
        ok(!DoorDashPendingPolicy.allowIdentityReset(1,true),"even verified new read must wait for expiry of stage 1");
        ok(!DoorDashPendingPolicy.allowIdentityReset(2,false),"stage 2 waits for dismissal");
        ok(DoorDashPendingPolicy.allowIdentityReset(2,true),"new verified financial offer after stage 2");
        ok(DoorDashPendingPolicy.allowIdentityReset(0,false),"normal offer reset");
        ok(!DoorDashPendingPolicy.expired(1,1000,35000,3000),"watchdog or OCR cannot erase valid pending session");
        ok(DoorDashPendingPolicy.expired(1,1000,35000,14000),"bounded session expiry");
        ok(DoorDashPendingPolicy.timerMatches(1,1931,1871,27,1000,32000,5000,0),"confirmation valid across window replacement with matching timer");
        ok(!DoorDashPendingPolicy.timerMatches(0,1931,-1,27,0,0,5000,0),"unarmed dialog never automatically confirmed");
        ok(!DoorDashPendingPolicy.timerMatches(1,1931,1871,-1,1000,32000,5000,0),"unknown timer cannot authorize changed window");
        ok(!DoorDashPendingPolicy.timerMatches(1,1931,1871,2,1000,32000,5000,0),"unrelated timer blocked");
        ok(UberDeclineRetry.holdMillis(1)==90&&UberDeclineRetry.holdMillis(3)==200,"bounded alternative press duration");
        System.out.println("Stability 2.6.1: "+count+" assertions passed");
    }
}
