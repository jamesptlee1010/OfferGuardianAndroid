package com.personal.offerguardian;
public class TouchMethodStandaloneTest {
    private static int checks;
    private static void check(boolean ok){checks++;if(!ok)throw new AssertionError("Failed assertion "+checks);}
    public static void main(String[] args){
        check(TouchMethod.normalize(-1)==0);check(TouchMethod.normalize(99)==0);
        check(TouchMethod.tryNative(0));check(TouchMethod.allowGesture(0));
        check(TouchMethod.tryNative(1));check(!TouchMethod.allowGesture(1));
        for(int i=2;i<=4;i++){check(!TouchMethod.tryNative(i));check(TouchMethod.allowGesture(i));for(int a=1;a<=3;a++)check(TouchMethod.duration(i,a)==(i-1)*100);}
        check(TouchMethod.normalize(5)==5);check(!TouchMethod.tryNative(5));check(!TouchMethod.allowGesture(5));
        check(TouchMethod.duration(0,1)==90);check(TouchMethod.duration(0,2)==140);check(TouchMethod.duration(0,3)==200);
        System.out.println("TouchMethod: "+checks+" assertions passed");
    }
}
