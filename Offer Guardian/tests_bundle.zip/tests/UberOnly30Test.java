package com.personal.offerguardian;
import java.util.Arrays;
final class UberOnly30Test {
    private static int count;
    static void ok(boolean v,String s){count++;if(!v)throw new AssertionError(s);}
    static OfferScreenEvaluator.Line l(String s,int y){return new OfferScreenEvaluator.Line(s,62,y,600,y+30);}
    static OfferDetailsParser.Details details(String duration){return OfferDetailsParser.parse(522,Arrays.asList(l("Delivery",500),l("$33.03",570),l("Est. earnings for completed trip",640),l(duration,700),l("Hungry Jacks",820),l("Some Street, Windsor",920)));}
    static boolean same(String typeB,int amount,int mins,int metres,int count,String merchant,String dest,long age){return OfferHistoryDedup.same(age,"Delivery",typeB,4670,amount,21,mins,9000,metres,1,count,"HungryJacks (Herston)",merchant,"Brown Street & Hooker Street, Windsor",dest);}
    public static void main(String[] args){
        for(String raw:new String[]{") l hr l min (9.4 km) total",") lhr lmin (9,4 km) total",") l hrl min (9,4 km) total",") I hr I min (9.4 km) total"}){
            OfferDetailsParser.Details d=details(raw);ok(d.minutes==61&&d.metres==9400,raw+" parsed as "+d.minutes+" / "+d.metres);ok(OfferExtractionGuard.check(d).valid,"corrected duration passes");ok(d.rawDuration.equals(raw),"raw preserved");
        }
        ok(!OfferExtractionGuard.check(details("1 hr (9.4 km) total")).valid,"partial hour stays uncertain");
        ok(details("O 22 min (3.4 km) total").minutes==22,"clock artifact not hour");
        ok(same("Delivery",4670,21,9000,1,"YP Hungry Jacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"OCR prefix");
        ok(same("Delivery",4670,21,9000,1,"Hungry.Jacks (Herston)","Brown Street & Hooker Street, Windsor",3000),"punctuation");
        ok(OfferHistoryDedup.merchantSimilar("P Guzman y Gomez (Bowen","Y Guzman y Gomez (Bowen"),"GYG prefix variation");
        ok(OfferHistoryDedup.merchantSimilar("P Guzman y Gomez (Bowen","Guzmany Gomez (Bowen"),"GYG space variation");
        ok(!same("DoorDash · Delivery",4670,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"platform distinct");
        ok(!same("Delivery",4671,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"payout distinct");
        ok(!same("Delivery",4670,22,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"time distinct");
        ok(!same("Delivery",4670,21,9100,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"distance distinct");
        ok(!same("Delivery",4670,21,9000,2,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",1000),"count distinct");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","Other Road, Windsor",1000),"destination distinct");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","",1000),"missing destination");
        ok(!same("Delivery",4670,21,9000,1,"HungryJacks (Herston)","Brown Street & Hooker Street, Windsor",61000),"separate time");
        ok(UberDeclineRetry.holdMillis(1)==90&&UberDeclineRetry.holdMillis(3)==200,"bounded alternative press duration");
        UberDeclineRetry retry=new UberDeclineRetry();
        retry.observe("1257/28",1000);ok(retry.ready(1000),"first offer ready");
        ok(retry.attempt(1000)==1,"first attempt");ok(!retry.ready(1200),"cooldown enforced");
        retry.observe("1257/28",2500);ok(retry.attempt(2500)==2,"same offer retains budget");
        retry.observe("1903/42",2600);ok(retry.ready(2600)&&retry.attempt(2600)==1,"new offer resets attempt budget");
        retry.observe("1903/42",4100);ok(retry.attempt(4100)==2,"second attempt");retry.observe("1903/42",5600);ok(retry.attempt(5600)==3&&!retry.canAttempt(),"bounded retries");
        retry.observe("1807/40",5700);ok(retry.ready(5700)&&retry.attempt(5700)==1,"new offer after exhaustion resets");
        retry.reset();retry.observe("blocked",1000);retry.defer(1000);
        ok(retry.attempts()==0&&retry.canAttempt()&&!retry.ready(1200),"blocked request preserves budget and cooldown");
        retry.observe("blocked",2500);ok(retry.ready(2500),"blocked request can reverify");
        retry.defer(2500);ok(retry.attempts()==0,"second blocked request still no dispatched attempt");
        ok(retry.attempt(2600)==1,"first actual dispatch counted");
        OfferRuleEngine.Config rule=new OfferRuleEngine.Config(false,0,true,30,false,0,OfferRuleEngine.Mode.ANY,false,1);
        ok(OfferRuleEngine.evaluate(rule,18.03,31,7800,2).outcome==OfferRuleEngine.Outcome.SHOW,"Woolworths qualifies");
        ok(OfferRuleEngine.evaluate(rule,18.07,40,8800,1).outcome==OfferRuleEngine.Outcome.DECLINE,"Coles heavy fails");
        ok(OfferRuleEngine.evaluate(rule,19.03,42,7900,1).outcome==OfferRuleEngine.Outcome.DECLINE,"Coles pack fails");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.UBER,true,true,1,.99),"single frame cannot decline");
        ok(!OfferSurfacePolicy.allowDecline(OfferSurfacePolicy.Host.UBER,true,false,2,.99),"offer identity required");
        System.out.println("Uber-only 3.0.0: "+count+" assertions passed");
    }
}
