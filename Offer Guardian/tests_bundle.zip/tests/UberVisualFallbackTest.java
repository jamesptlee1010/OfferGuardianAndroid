package com.personal.offerguardian;
public class UberVisualFallbackTest {
 static int n=0;
 static void check(boolean b){n++;if(!b)throw new AssertionError("assertion "+n);}
 static void add(UberVisualFallback v,int id,String key,double score,long at){v.observe(id,"DOORDASH","Exclusive",key,579,708,634,score,true,at,at+1200);}
 static boolean ready(UberVisualFallback v,int id,String key,long at){return v.ready(id,"DOORDASH","Exclusive",key,579,708,634,.987,true,at,at+1250);}
 public static void main(String[] a){
 UberVisualFallback v=new UberVisualFallback();String k="12.55/28/8300/2/Delivery";
 add(v,1648,k,.987,1000);check(!ready(v,1648,k,1000));
 add(v,1648,k,.987,1000);check(!ready(v,1648,k,1000));
 add(v,1648,k,.99,2400);check(ready(v,1648,k,2400));
 check(!ready(v,1649,k,2400));check(!ready(v,1648,"changed",2400));check(!ready(v,-1,k,2400));
 check(!v.ready(1648,"DOORDASH","Exclusive",k,579,708,634,.93,true,2400,3650));
 check(!v.ready(1648,"DOORDASH","Exclusive",k,579,708,634,.99,false,2400,3650));
 check(!v.ready(1648,"DOORDASH","Exclusive",k,579,708,634,.99,true,2400,4500));
 check(!v.ready(1648,"DOORDASH","Exclusive",k,590,708,634,.99,true,2400,3650));
 check(!v.ready(1648,"OTHER","Exclusive",k,579,708,634,.99,true,2400,3650));
 add(v,1648,k,.99,3800);check(ready(v,1648,k,3800));
 add(v,1648,"new price",.99,5200);check(!ready(v,1648,"new price",5200));
 add(v,1648,"new price",.99,6600);check(ready(v,1648,"new price",6600));
 add(v,1649,"new price",.99,8000);check(!ready(v,1649,"new price",8000));
 add(v,1649,"new price",.99,13000);check(!ready(v,1649,"new price",13000));
 v.reset();check(v.frames()==0);System.out.println("UberVisualFallback: "+n+" assertions passed");
 }
}
