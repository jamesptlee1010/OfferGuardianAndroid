"""Host-side SQLite regression checks for lossless CSV-history merge identity.

The source's import SQL matches on a one-second window because exported
OfferGuardian CSV timestamps truncate the millisecond portion of seen_at.
"""
import sqlite3
from pathlib import Path

DB_SOURCE = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/personal/offerguardian/OfferHistoryStore.java'
src = DB_SOURCE.read_text()
assert 'seen_at>=? AND seen_at<? AND payout_cents=? AND pickup=? AND destination=?' in src
assert 'db.beginTransaction()' in src and 'db.setTransactionSuccessful()' in src
assert 'db.endTransaction()' in src

conn = sqlite3.connect(':memory:')
conn.execute('''CREATE TABLE offers(id INTEGER PRIMARY KEY, seen_at INTEGER NOT NULL,
              payout_cents INTEGER, pickup TEXT, destination TEXT, type TEXT)''')
conn.execute("INSERT INTO offers(seen_at,payout_cents,pickup,destination,type) VALUES(?,?,?,?,?)",
             (1795321829384,2966,'Coles (Kedron)','Kate Street','Pack & Deliver'))

# Export has no milliseconds, and older exports may have generic type.
query = '''SELECT id FROM offers WHERE seen_at>=? AND seen_at<? AND payout_cents=?
           AND pickup=? AND destination=? LIMIT 1'''
assert conn.execute(query,(1795321829000,1795321830000,2966,'Coles (Kedron)','Kate Street')).fetchone()
assert conn.execute(query,(1795321830000,1795321831000,2966,'Coles (Kedron)','Kate Street')).fetchone() is None
assert conn.execute(query,(1795321829000,1795321830000,2967,'Coles (Kedron)','Kate Street')).fetchone() is None
assert conn.execute(query,(1795321829000,1795321830000,2966,'Coles (Kedron)','Different destination')).fetchone() is None

# Multiple rows in one import can be tested in the same uncommitted transaction.
with conn:
    conn.execute('INSERT INTO offers(seen_at,payout_cents,pickup,destination,type) VALUES(?,?,?,?,?)',
                 (1795321829000,1332,'Second shop','Other street','Delivery'))
    assert conn.execute(query,(1795321829000,1795321830000,1332,'Second shop','Other street')).fetchone()

print('History CSV dedup SQLite scenarios passed')
